library(testthat)
library(rhdf5)

test_check("rhdf5")
