library(testthat)
library(sleuth)

test_check("sleuth")
