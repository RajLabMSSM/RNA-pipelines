# aggregation
Methods for aggregating p-values

How to install:
In R:
devtools::install_github('pachterlab/aggregation')
